<?php
session_start();

if (!key_exists('calculator', $_SESSION)) {
    $_SESSION['calculator']['operation'] = init_calculator('operation');
    $_SESSION['calculator']['template']  = init_calculator('template');
    $_SESSION['calculator']['memory']    = init_calculator('memory');
    $_SESSION['calculator']['mode']      = init_calculator('mode');
}
$calculator = $_SESSION['calculator'];

$operation  = $calculator['operation'];
$template   = $calculator['template'];
$memory     = $calculator['memory'];
$mode       = $calculator['mode'];

$post       = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
$flagMemory = null;
$mathCode   = '';

if (!empty($post)) {
    if (key_exists('reset', $post)) {
        $operation = init_calculator('operation');
    } else if (key_exists('template', $post)) {
        $template = $post['template'];
    } else if (key_exists('mode', $post)) {
        $mode = $post['mode'];
    } else {
        $current = $operation['current'];
        $enter   = $operation['enter'];
        $last    = $operation['last'];
        $rewind  = $operation['rewind'];

        if (!key_exists('error', $current)) {
            if (key_exists('numeric', $post)) {
                $rewind  = false;
                $numeric = $post['numeric'];
                $end     = end($current);
                $concat  = $end . $numeric;

                if (is_numeric($concat)) {
                    if ($enter == true) {
                        $concat = '0' . $numeric;
                        $enter  = false;
                    }
                    $current[count($current) - 1] = (substr_count($concat, '.') == 1) ? ($concat) : ($concat) + 0;
                }
            } else if (key_exists('operator', $post)) {
                $current[0]+= 0;
                $enter      = false;
                $_current   = array_trim($current);

                if (count($_current) == 3) {
                    $total      = total($current);
                    $current[0] = implode($total);
                }
                $current[1] = $post['operator'];
                $current[2] = '';
            } else if (key_exists('math', $post)) {
                $math     = str_replace(array('&radic;'), array('sqrt'), strtolower(htmlentities($post['math'])));
                $_current = array_trim($current);

                if (count($_current) == 1 || count($_current) == 3) {
                    $key = (count($_current) == 3) ? 2 : 0;

                    if ($math == '&plusmn;') {
                        $current[$key] = 0 - end($_current);
                    } else if (is_callable($math)) {
                        if ($key == 2) {
                            $mathCode = sprintf('%s %s %s(%s);', $current[0], $current[1], $math, $current[2]);
                            $rewind   = false;
                        } else {
                            $mathCode = sprintf('%s(%s)', $math, $current[0]);
                            $rewind   = true;
                            $enter    = true;
                        }
                        if ($math == 'pi') {
                            $mathCode = str_replace("$math({$current[$key]})", "$math()", $mathCode);
                        }
                        $current[$key] = call_user_func($math, $current[$key]);
                        $last[$key]    = $current[$key];
                    }
                } else {
                    if (count($_current == 2) && $math == 'pi') {
                        $mathCode   = sprintf('%s %s %s();', $current[0], $current[1], $math);
                        $current[2] = pi();
                    }
                }
            } else if (key_exists('m+', $post)) {
                $_current   = array_replace($current, array(1 => ''));
                $__current  = array_trim($_current);
                $memory[]   = end($__current);
                $enter      = (count($current) == 3) ? false : true;
                $flagMemory = 'M';
            }

            if (key_exists('enter', $post)) {
                if ($enter == true && count($last) == 3) {
                    $last[0] = implode(total($last));
                    $current = $last;
                    $enter   = false;
                }

                if (count($current) == 1) {
                    $last  = array();
                    $enter = true;
                } else {
                    $_current = array_trim($current);

                    if (count($_current) == 3) {
                        if ($enter == false) {
                            $last  = $current;
                            $enter = true;
                        }
                        if ($rewind == true) {
                            $total = array($last[0]);
                        } else {
                            $total = total($current);
                        }
                        $current = $total;
                    }
                }
            }
        }

        if (key_exists('erase', $post)) {
            if (key_exists('error', $current)) {
                $enter   = false;
                $current = $last;
            } else {
                if ($enter == false) {
                    $current = array_trim($current);
                    $_end    = end($current);
                    $end     = strtoupper($_end);

                    if (strpos($end, 'E') !== false) {
                        $end   = strstr($end, 'E', true);
                        $value = str_replace('.', '', $end);
                    } else {
                        $value = substr($end, 0, -1);
                    }
                    $current[count($current) - 1] = (count($current) == 1 && $value == '') ? '0' : $value;
                    $_current = array_trim($current);

                    if (count($_current) == 2) {
                        $current[2] = '';
                    }
                }
            }
        } else if (key_exists('mc', $post)) {
            $memory     = init_calculator('memory');
            $flagMemory = 'MC';
        } else if (key_exists('mr', $post)) {
            $current[(count($current) == 3) ? 2 : 0] = $post['mr'];
        } else {
            if (key_exists('m-', $post) && count($memory) > 1) {
                array_pop($memory);
                $flagMemory = 'M-';
            }
        }
        $operation['current'] = $current;
        $operation['enter']   = $enter;
        $operation['last']    = $last;
        $operation['rewind']  = $rewind;
    }
}
$output  = format_output($operation['current']);
$phpSelf = filter_input(INPUT_SERVER, 'PHP_SELF');

$_SESSION['calculator']['operation'] = $operation;
$_SESSION['calculator']['template']  = $template;
$_SESSION['calculator']['memory']    = $memory;
$_SESSION['calculator']['mode']      = $mode;

/**
 * FUNCTIONS
 */
function init_calculator($key) {
    $array = array(
        'operation'   => array(
            'current' => array('0'),
            'last'    => array(),
            'enter'   => false,
            'rewind'  => false
        ),
        'template' => 'portrait',
        'mode'     => 'basic',
        'memory'   => array('MR')
    );
    return $array[$key];
}

function callback_array_trim($value) {
    return $value !== '';
}

function array_trim($array) {
    return array_filter($array, 'callback_array_trim');
}

function total($data) {
    $array = (array) $data;
    if (count($array) == 3 && ($array[1] == '/' || $array[1] == '%') && $array[2] == 0) {
        $result = array('error' => 'ERROR');
    } else {
        foreach ($array as $k => $v) {
            $array[$k] = " $v ";
        }
        $arg    = implode($array);
        $func   = create_function('$arg', "return $arg;");
        $result = array($func($arg));
    }
    return $result;
}

function format_output($_array) {
    $array         = array_trim($_array);
    $listOperators = array('+', '-', '/', '*', '%');
    $numerics      = array_diff($array, $listOperators);

    foreach ($numerics as $k => $v) {
        if (abs($v) >= 1000) {
            $decimal = '';

            if (strpos($v, '.') !== false) {
                $decimal = strstr($v, '.');
                $v = strstr($v, '.', true);
            }
            $strrev  = strrev($v);
            $split   = str_split($strrev, 3);
            $reverse = array_reverse($split);

            foreach ($reverse as $kk => $vv) {
                $reverse[$kk] = strrev($vv);
            }
            $v = implode(' ', $reverse) . $decimal;
        }
        $array[$k] = trim($v);
    }
    $operator = current(array_intersect($array, $listOperators));

    if (!empty($operator)) {
        $array[1] = " $operator ";
    }
    return implode($array);
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <!--<meta http-equiv="X-UA-Compatible" content="IE=edge">-->	
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>PHP Calculator [Basic & Scientific]</title>
        <meta charset="UTF-8">
        <!--<link rel="stylesheet" href="css/customized-bootstrap.3.3.6/bootstrap.min.css">-->
        <!--<link rel="stylesheet" href="css/custom.css">-->		
        <style>
        <?php include('css/customized-bootstrap.3.3.6/bootstrap.min.css'); ?>
        <?php include('css/custom.min.css'); ?>
        </style>
    </head>
    <body>
        <noscript>
        <div class="alert alert-danger" id="noscript">
            <div class="container">
                <div class="text-center text-danger">
                    <!--<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>-->
                    <span><strong>Notice: </strong> JavaScript is not enabled. <a href="http://enable-javascript.com/" class="alert-link"><u>Please Enable JavaScript Safely</u></a>.</span>
                </div>
            </div>
        </div>
        </noscript>	
        <div class="container">
            <div id="center">			
                <?php
                if ($template == 'portrait') {
                    $size = (strlen($output) > 9) ? (29 - ((strlen($output) - 9) * 2)) : 29;
                    $fontSize = ($size < 15) ? 'font-size:15px;' : 'font-size:' . $size . 'px;';
                    ?>
                    <div class="" id="box-portrait"  style="margin-left:90px;">	
                        <div class="row">
                            <div class="col-md-12">
                                <form class="pull-right" method="post" action="<?php echo $phpSelf; ?>" style="margin-bottom:8px;">
                                    <input class="btn btn-default btn-xs" type="submit" id="template-landscape" name="template" value="landscape">	
                                </form>	
                                <form method="post" action="<?php echo $phpSelf; ?>" style="margin:0;margin-top:-1px;">
                                    <div class="form-group">
                                        <input type="radio" name="mode" value="basic" <?php echo ($mode == 'basic') ? 'checked' : ''; ?>  onchange="this.form.submit()">
                                        <input type="radio" name="mode" value="scientific" <?php echo ($mode == 'scientific') ? 'checked' : ''; ?>  onchange="this.form.submit()">
                                    </div>
                                </form>					
                            </div>
                        </div>
                        <div class="thumbnail">
                            <div id="portrait-input-lg-background">
                                <input class="form-control text-left" style="font-size:10px;font-weight:bold;padding: 0px 0px 0px 6px;margin:0;height:15px;cursor:none;background-color:black;color:white;" type="text" value="<?php echo (isset($flagMemory)) ? $flagMemory : $mathCode; ?>">
                                <input class="form-control input-lg" id="screen" style="<?php echo $fontSize; ?>margin-top:-13px;" type="text" name="screen" value="<?php echo $output; ?>" autofocus>
                            </div>
                        </div>
                        <?php if ($mode == 'scientific') : ?>
                            <div class="row">
                                <div class="col-md-12">							
                                    <?php
                                    $reverse = array_reverse($memory);
                                    $mr = array_pop($reverse);
                                    echo '<form class="form-inline pull-right" method="post" action="' . $phpSelf . '">';
                                    echo '<div class="form-group">';
                                    echo '<select class="btn btn-default btn-xs" name="mr" onchange="this.form.submit()" style="padding:0;">';
                                    echo '<option value="' . $mr . '" style="color:#999;cursor:not-allowed;">' . $mr . '</option>';
                                    foreach ($reverse as $v) {
                                        echo '<option value="' . $v . '" style="font-size:12px;">' . format_output(array($v)) . '</option>';
                                    }
                                    echo '</select>';
                                    echo '</div>';
                                    echo '</form>';
                                    ?>
                                    <form class="form-inline" method="post" action="<?php echo $phpSelf; ?>">
                                        <div class="form-group">
                                            <input class="btn btn-default btn-xs" type="submit" name="m+"    value="M">
                                            <input class="btn btn-default btn-xs" type="submit" name="m-"    value="M -">
                                            <input class="btn btn-default btn-xs" type="submit" name="mc"    value="MC">
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <form method="post" action="<?php echo $phpSelf; ?>" style="margin-bottom:8px;">	
                                <div class="form-group">
                                    <input class="btn btn-default btn-xs" type="submit" name="math" value="EXP">					
                                    <input class="btn btn-default btn-xs" type="submit" name="math" value="COS">
                                    <input class="btn btn-default btn-xs" type="submit" name="math" value="SIN">
                                    <input class="btn btn-default btn-xs" type="submit" name="math" value="TAN">
                                </div>
                                <div class="form-group">
                                    <input class="btn btn-default btn-xs" type="submit" name="math"    value="LOG">
                                    <input class="btn btn-default btn-xs" type="submit" name="math"    value="ACOS">
                                    <input class="btn btn-default btn-xs" type="submit" name="math"    value="ASIN">
                                    <input class="btn btn-default btn-xs" type="submit" name="math"    value="ATAN">					
                                </div>
                                <div class="form-group">
                                    <input class="btn btn-default btn-xs" type="submit" name="math"    value="&plusmn;">								
                                    <input class="btn btn-default btn-xs" type="submit" name="math"    value="ROUND">								
                                    <input class="btn btn-default btn-xs" type="submit" name="math"    value="&radic;">
                                    <input class="btn btn-default btn-xs" type="submit" name="math" value="PI">
                                </div>				
                            </form>
                        <?php endif; ?>

                        <form method="post" action="<?php echo $phpSelf; ?>">
                            <div class="form-group">					
                                <input class="btn btn-default" type="submit" name="reset"    value="C">
                                <input class="btn btn-default" type="submit" name="erase"    value="&larr;">
                                <input class="btn btn-default" type="submit" name="operator" value="%">
                                <input class="btn btn-default" type="submit" name="operator" value="+">
                            </div>
                            <div class="form-group">
                                <input class="btn btn-default" type="submit" name="numeric"  value="7">
                                <input class="btn btn-default" type="submit" name="numeric"  value="8">
                                <input class="btn btn-default" type="submit" name="numeric"  value="9">
                                <input class="btn btn-default" type="submit" name="operator" value="-">
                            </div>
                            <div class="form-group">
                                <input class="btn btn-default" type="submit" name="numeric" value="4">
                                <input class="btn btn-default" type="submit" name="numeric" value="5">
                                <input class="btn btn-default" type="submit" name="numeric" value="6">
                                <input class="btn btn-default" type="submit" name="operator" value="*">	
                            </div>
                            <div class="form-group">
                                <input class="btn btn-default" type="submit" name="numeric" value="1">
                                <input class="btn btn-default" type="submit" name="numeric" value="2">
                                <input class="btn btn-default" type="submit" name="numeric" value="3">
                                <input class="btn btn-default" type="submit" name="operator" value="/">
                            </div>
                            <div class="form-group">
                                <input class="btn btn-default" type="submit" name="numeric" value=".">
                                <input class="btn btn-default" type="submit" name="numeric" value="0">
                                <input class="btn btn-default" type="submit" name="enter" value="=" id="portrait-enter">	
                            </div>						
                        </form>	
                    </div>
                <?php } ?>
                <?php
                if ($template == 'landscape') {
                    $size = (strlen($output) > 19) ? (29 - ((strlen($output) - 19) * 2)) : 29;
                    $fontSize = ($size < 15) ? 'font-size:15px;' : 'font-size:' . $size . 'px;';
                    ?>
                    <div id="box-landscape" style="margin-left:23px;">
                        <div class="row">
                            <div class="col-md-12">
                                <form class="pull-right" method="post" action="<?php echo $phpSelf; ?>" style="margin-bottom:8px;">
                                    <input class="btn btn-default btn-xs" type="submit" id="template-portrait" name="template" value="portrait">	
                                </form>	
                                <form method="post" action="<?php echo $phpSelf; ?>" style="margin:0;margin-top:-1px;">
                                    <input type="radio" name="mode" value="basic" <?php echo ($mode == 'basic') ? 'checked' : ''; ?>  onchange="this.form.submit()">
                                    <input type="radio" name="mode" value="scientific" <?php echo ($mode == 'scientific') ? 'checked' : ''; ?>  onchange="this.form.submit()">
                                </form>					
                            </div>
                        </div>
                        <div class="thumbnail">
                            <div id="landscape-input-lg-background">
                                <input class="form-control text-left" style="font-size:10px;font-weight:bold;padding: 0px 0px 0px 6px;margin:0;height:15px;cursor:none;background-color:black;color:white;" type="text" value="<?php echo (isset($flagMemory)) ? $flagMemory : $mathCode; ?>">                         							
                                <input class="form-control input-lg" id="screen" style="<?php echo $fontSize; ?>margin-top:-13px;" type="text" name="screen" value="<?php echo $output; ?>" autofocus>
                            </div>
                        </div>	
                        <?php if ($mode == 'scientific') : ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <?php
                                    $reverse = array_reverse($memory);
                                    $mr = array_pop($reverse);
                                    echo '<form class="form-inline pull-right" method="post" action="' . $phpSelf . '">';
                                    echo '<div class="form-group">';
                                    echo '<select class="btn btn-default btn-xs" name="mr" onchange="this.form.submit()" style="padding:0;width:176px;">';
                                    echo '<option value="' . $mr . '" style="color:#999;cursor:not-allowed;">' . $mr . '</option>';
                                    foreach ($reverse as $v) {
                                        echo '<option value="' . $v . '" style="font-size:12px;">' . format_output(array($v)) . '</option>';
                                    }
                                    echo '</select>';
                                    echo '</div>';
                                    echo '</form>';
                                    ?>
                                    <form class="form-inline" method="post" action="<?php echo $phpSelf; ?>">
                                        <div class="form-group">
                                            <input class="btn btn-default btn-xs" type="submit" name="m+"    value="M">
                                            <input class="btn btn-default btn-xs" type="submit" name="m-"    value="M -">
                                            <input class="btn btn-default btn-xs" type="submit" name="mc"    value="MC">
                                        </div>
                                    </form>                                
                                </div>
                            </div>

                            <form method="post" action="<?php echo $phpSelf; ?>" style="margin-bottom:8px;">
                                <div class="form-group">						
                                    <input class="btn btn-default btn-xs" type="submit" name="null" value="NULL" style="color:transparent;">							
                                    <input class="btn btn-default btn-xs" type="submit" name="math" value="EXP">                            							
                                    <input class="btn btn-default btn-xs" type="submit" name="math" value="COS">
                                    <input class="btn btn-default btn-xs" type="submit" name="math" value="SIN">
                                    <input class="btn btn-default btn-xs" type="submit" name="math" value="TAN">
                                    <input class="btn btn-default btn-xs" type="submit" name="math" value="LOG">							
                                    <input class="btn btn-default btn-xs" type="submit" name="null" value="NULL" style="color:transparent;">
                                </div>
                                <div class="form-group">
                                    <input class="btn btn-default btn-xs" type="submit" name="math" value="&plusmn;">								
                                    <input class="btn btn-default btn-xs" type="submit" name="math" value="ROUND">							
                                    <input class="btn btn-default btn-xs" type="submit" name="math" value="ACOS">
                                    <input class="btn btn-default btn-xs" type="submit" name="math" value="ASIN">
                                    <input class="btn btn-default btn-xs" type="submit" name="math" value="ATAN">							
                                    <input class="btn btn-default btn-xs" type="submit" name="math" value="&radic;">
                                    <input class="btn btn-default btn-xs" type="submit" name="math" value="PI">	
                                </div>
                            </form>
                        <?php endif; ?>

                        <form method="post" action="<?php echo $phpSelf; ?>">
                            <div class="form-group">
                                <input class="btn btn-default" type="submit" name="reset"   value="C">
                                <input class="btn btn-default" type="submit" name="numeric" value="6">
                                <input class="btn btn-default" type="submit" name="numeric" value="7">
                                <input class="btn btn-default" type="submit" name="numeric" value="8">
                                <input class="btn btn-default" type="submit" name="numeric" value="9">
                                <input class="btn btn-default" type="submit" name="numeric" value="0">
                                <input class="btn btn-default" type="submit" name="erase"  value="&larr;">
                            </div>
                            <div class="form-group">
                                <input class="btn btn-default" type="submit" name="operator" value="*">
                                <input class="btn btn-default" type="submit" name="numeric" value="1">
                                <input class="btn btn-default" type="submit" name="numeric" value="2">
                                <input class="btn btn-default" type="submit" name="numeric" value="3">
                                <input class="btn btn-default" type="submit" name="numeric" value="4">	
                                <input class="btn btn-default" type="submit" name="numeric" value="5">
                                <input class="btn btn-default" type="submit" name="operator" value="+">
                            </div>
                            <div class="form-group">
                                <input class="btn btn-default" type="submit" name="operator" value="/">
                                <input class="btn btn-default" type="submit" name="numeric" value=".">
                                <input class="btn btn-default" type="submit" name="enter"    value="=" id="landscape-enter">
                                <input class="btn btn-default" type="submit" name="operator" value="%">			
                                <input class="btn btn-default" type="submit" name="operator" value="-">	
                            </div>					
                        </form>	
                    </div>   
                <?php } ?>	
            </div>		
        </div>
        <script type="text/javascript">
            /* http://codetheory.in/javascript-control-input-field-caret-position-or-move-to-end-in-textboxes-and-textareas/ */
            var input = document.querySelector('#screen');
            var reset = function () {
                var len = this.value.length;
                this.setSelectionRange(len, len);
            };
            input.addEventListener('focus', reset, false);
            /*input.addEventListener('mouseup', reset, false);
             input.addEventListener('keyup', reset, false);
             input.addEventListener('keydown', reset, false);*/
        </script> 	
    </body>
</html>	
