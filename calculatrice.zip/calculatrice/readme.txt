PHP Calculator [Basic & Scientific] - Experimental.13.01.2016-------------------------------------------------------------
Url     : http://codes-sources.commentcamarche.net/source/101332-php-calculator-basic-scientific-experimental-13-01-2016Auteur  : us2rp4ssDate    : 18/01/2016
Licence :
=========

Ce document intitul� � PHP Calculator [Basic & Scientific] - Experimental.13.01.2016 � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Addition - Soustraction - Multiplication - Division - Modulo - PHP Math Function
s
<br />- Switch &gt; mode Basic & Scientific
<br />- Switch &gt; template Por
trait & Landscape
<br />- Screen &gt; Font LCD + Font size adaptif
<br />- Res
et & Erase last
<br />
<br />Note: 
<br />- HTML fait sans tableau. 
<br />-
 CSS fait avec Bootstrap.3.3.6 (version customized). 
<br />- PHP Calculator te
ster uniquement sur Firefox.40.0.3 & IE 11 (differences affichage sur IE)
<br /
>- L'utilisation des balises &lt;link&gt; provoque un bug du curseur. Pourquoi ?
 
<br />  (Balises sous commentaire)
<br />
<br />Mode Scientific:
<br />- A
 l'aide des touches numeriques entrez une valeur (ou bien laissez la valeur en c
ours) et pressez ensuite sur une touche PHP Math Function
<br />- Description d
es PHP Math Functions: <a href='http://php.net/manual/fr/ref.math.php' rel='nofo
llow' target='_blank'>http://php.net/manual/fr/ref.math.php</a> 
<br />- Voir: 
<a href='http://www.lecoindunet.com/touches-m-m-mr-et-mc-sur-une-calculatrice-a-
quoi-ca-sert-269' rel='nofollow' target='_blank'>http://www.lecoindunet.com/touc
hes-m-m-mr-et-mc-sur-une-calculatrice-a-quoi-ca-sert-269</a>
<br />
<br />- LI
VE DEMO: <a href='http://bit.ly/us2rp4ss-demo-php-calculator' rel='nofollow' tar
get='_blank'>http://bit.ly/us2rp4ss-demo-php-calculator</a>
<br />- Ceux qui ve
ulent uniquement le mode basic <a href='http://bit.ly/php-calculator-basic' rel=
'nofollow' target='_blank'>http://bit.ly/php-calculator-basic</a>
<br />
<br /
><b>Malgré l'update le code PHP comporte quelques oublis.</b> 
<br />Prochaine
 mise à jour (déjà visible dans la LIVE DEMO):
<br /><i>- Ajout: de &quot;fl
ag&quot; dans le screen lorsque vous pressez les touches M, M- et MC
<br />- Aj
out: dans le screen du nom de la PHP Math Functions en cours
<br />- Correction
: actuellement la valeur se trouvant APRES l'operateur est oubliée lors de l'ut
ilisation des PHP Math Functions.</i>
<br />- Correction: les valeurs selection
nées dans MR pourront etre placées dans le screen AVANT ou APRES l'operateur

<br />
<br /><b>Tous les résultats obtenus avec PHP Calculator[Basic & Scienti
fic] ont été comparé avec ceux de la calculatrice de Windows 8.1. </b>
