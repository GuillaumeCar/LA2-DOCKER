CREATE DATABASE wisemapping;
CREATE USER wisemapping WITH PASSWORD 'password';
GRANT ALL PRIVILEGES ON DATABASE wisemapping TO wisemapping;
