// Brazilian Portuguese 
jQuery.timeago.settings.strings = {
    suffixAgo: "atrás",
    suffixFromNow: "nesse momento",
    seconds: "alguns segundos",
    minute: "há um minuto",
    minutes: "há %d minutos",
    hour: "há uma hora",
    hours: "há %d horas",
    day: "há um dia",
    days: "há %d dias",
    month: "há um mês",
    months: "há %d meses",
    year: "há um ano",
    years: "há %d anos"
};