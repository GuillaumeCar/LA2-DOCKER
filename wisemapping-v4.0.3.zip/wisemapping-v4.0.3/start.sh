#!/bin/sh

java -Xmx256m -Dorg.apache.jasper.compiler.disablejsr199=true -jar start.jar

